<div id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title text-danger text-center">No tiene permisos para usar este modulo</h2>
            </div>
            <div class="modal-body">
              <p><b>Por favor consulte con su adminsitrador</b></p>
            </div>
        </div>
    </div>
</div>
<div class="text-center">
<a href="javascript:history.back()" class="btn btn-danger">
                    <i class="fa fa-arrow-left"></i> Volver</a>
</div>