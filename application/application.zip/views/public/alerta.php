<font size="5"><span class="text-danger"><span class="fa fa-times-circle"> NO TIENE PERMISO PARA ACCEDER A ESTA SECCION</span></span></font><br><br><br>
	<a href="javascript: history.go(-1)" class="btn btn-success">Volver</a>
